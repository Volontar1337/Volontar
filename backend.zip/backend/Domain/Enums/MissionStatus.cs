namespace Domain.Enums
{
    public enum MissionStatus
    {
        Upcoming,
        Active,
        Completed
    }
}