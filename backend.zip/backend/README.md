# Volontar Backend

This directory is for your backend API server. You can use any backend technology (Node.js, Express, Django, etc.).

## Getting Started

1. Initialize your backend project here (e.g., `npm init`, `pipenv`, etc.).
2. Add your backend code and documentation.

---

For frontend development, see the `../frontend` directory.
