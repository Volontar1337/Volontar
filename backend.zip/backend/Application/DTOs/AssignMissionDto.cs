namespace Application.DTOs
{
    public class AssignMissionDto
    {
        public Guid MissionId { get; set; }
    }
}
