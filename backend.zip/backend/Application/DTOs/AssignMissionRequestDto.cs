namespace Application.DTOs
{ 
    public class AssignMissionRequestDto
    {
    public Guid MissionId { get; set; }
    }
}