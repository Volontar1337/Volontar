namespace Application.DTOs
{
    public class RegisterResponseDto
    {
        public Guid UserId { get; set; }
    }
}