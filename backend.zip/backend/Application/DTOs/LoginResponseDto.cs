namespace Application.DTOs
{
    public class LoginResponseDto
    {
        public string? UserId { get; set; }
        public string? Email { get; set; }
    }
}

